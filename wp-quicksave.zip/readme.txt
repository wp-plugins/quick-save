=== Quick Save ===
Contributors: Stev
Donate link: Give it to charity.
Tags: keystroke, key, save, publish, update, fast, speed
Requires at least: 3.8
Tested up to: 4.2.2
Stable tag: 1.0

Press the ALT key to update posts and pages instead of clicking the Update button all the time.

== Description ==

When editing in Text mode the Quick Save Wordpress plugin lets you update posts and pages using keystrokes as well as by clicking the Publish/Update button.
By default the ALT key is used to save posts/pages however you can change this from the Settings menu if you have the Pro version.
See Quick Save Keystroke in Settings menu for more information.

#### Top features
* Saves time scrolling up and down the page to click the Update button

#### Languages/translations

The plugin is available in English:


#### Donation and more plugins
* If you like this plugin just upgrade to the Pro version. If you want to donate, give it to charity.
* Check out some [more WordPress Plugins & Software](http://www.stevs.net) by the same author.

== Installation ==

1. Upload the wp-quicksave.zip on the Plugins > Add New page.
1. Activate the plugin through the "Plugins" menu in WordPress
1. Done!

Now when you edit in Text mode you can update the page/post by pressing the ALT key.

== Screenshots ==

1. You can press the ALT key to update the post or page.


== Changelog ==

= 0.1 =
- It's alive!